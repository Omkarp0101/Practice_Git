package com.registration.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.registration.Entity.User;

@Repository
public class UserDao {

	@Autowired
	SessionFactory factory;

	//Register user in database.
	public String registerUser(User user) {

		Session session = factory.openSession();

		session.save(user);

		session.beginTransaction().commit();

		return "User Registered Successfully";

	}

	//Check Existing user.
	public boolean checkUserName(String username) {

		Session session = factory.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("username", username));
		User uName = (User) criteria.uniqueResult();
		if (uName != null) {
			return true;
		} else {
			return false;
		}
	}

	//Check Existing email.
	public boolean checkMail(String email) {

		Session session = factory.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("email", email));
		User eId = (User) criteria.uniqueResult();
		if (eId != null) {
			return true;
		} else {
			return false;
		}
	}

	//Login user, check usernameORemail and password
	public String loginUser(User user) {
		// System.out.println(user.getPassword());
		Session session = factory.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.or(Restrictions.eq("username", user.getUsername()),
				Restrictions.eq("email", user.getEmail())));
		criteria.add(Restrictions.eq("password", user.getPassword()));
		User login = (User) criteria.uniqueResult();
		if (login != null) {
			return "Login successfull";
		} else {
			return "Failed..!";
		}
	}

	/*
	 * public boolean checkPassword(String password) {
	 * 
	 * Session session = factory.openSession();
	 * 
	 * Criteria criteria = session.createCriteria(User.class);
	 * 
	 * criteria.add(Restrictions.eq("password", password));
	 * 
	 * User pass = (User) criteria.uniqueResult(); if(pass.equals(password)) {
	 * return true; }else { return false; } }
	 */

}
