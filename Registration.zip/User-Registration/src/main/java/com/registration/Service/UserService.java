package com.registration.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registration.Dao.UserDao;
import com.registration.Entity.User;
import com.registration.configuration.CheckEmail;
import com.registration.configuration.CheckPassword;
import com.registration.configuration.EncryptPassword;

@Service
public class UserService {

	@Autowired
	UserDao dao;

	// Register user.
	public String registerUser(User user) {

		String msg = null;

		boolean check1 = dao.checkUserName(user.getUsername());
		boolean check2 = dao.checkMail(user.getEmail());

		if (CheckEmail.checkEmail(user.getEmail()) && CheckPassword.checkPass(user.getPassword())) {

			// Password encryption.
			String encryptPass = EncryptPassword.encryptPass(user.getPassword());
			user.setPassword(encryptPass);

			if (check1) {
				return "Username Already Exist...!";
			} else if (check2) {
				return "Email Already Exist...!";
			} else {
				msg = dao.registerUser(user);
			}
		} else {
			return "Invalid username OR password";
		}

		return msg;

	}

	// Login user
	public String loginUser(User user) {
		// Password Encryption.
		String encryptPass = EncryptPassword.encryptPass(user.getPassword());
		user.setPassword(encryptPass);
		// System.out.println(user.getPassword());
		return dao.loginUser(user);

	}

}
