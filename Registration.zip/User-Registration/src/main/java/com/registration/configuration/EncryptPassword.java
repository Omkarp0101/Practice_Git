package com.registration.configuration;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.stereotype.Component;

@Component
public final class EncryptPassword {

	// Password encryption.
	public static final String encryptPass(String password) {

		try {
			MessageDigest md = MessageDigest.getInstance("MD5");

			md.update(password.getBytes());

			byte[] bytes = md.digest();

			StringBuilder sb = new StringBuilder();
			for (byte b : bytes) {
				sb.append(String.format("%02x", b));
			}

			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			// Handle the exception
			throw new RuntimeException("MD5 algorithm not found", e);
		}

	}

	/*
	 * public static void main(String[] args) {
	 * EncryptPassword.encryptPass("omkar123"); }
	 */
}
