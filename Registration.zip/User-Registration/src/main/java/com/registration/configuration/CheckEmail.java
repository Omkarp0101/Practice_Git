package com.registration.configuration;

import org.springframework.stereotype.Component;

@Component
public final class CheckEmail {

	// Email verification
	public static final boolean checkEmail(String email) {

		if (email.contains("@")) {
			return true;
		} else {
			return false;
		}
	}
}
