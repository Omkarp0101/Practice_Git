package com.registration.configuration;

import org.springframework.stereotype.Component;

@Component
public final class CheckPassword {

	// Password verification.
	public static final boolean checkPass(String password) {

		if (password.length() >= 8) {
			return true;
		} else {
			return false;
		}
	}
}
